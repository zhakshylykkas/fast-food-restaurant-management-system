package com.example.restaurantis;

import com.example.restaurantis.DBTableClasses.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;

import java.io.IOException;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;

public class MenuPageController implements CardProductController.ProductSelectionListener {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField amountTakenTextField;

    @FXML
    private Button burgersBtn;

    @FXML
    private RadioButton carryOutBtn;

    @FXML
    private Label changeAmountLabel;

    @FXML
    private RadioButton deliveryBtn;

    @FXML
    private Button dessertsBtn;

    @FXML
    private RadioButton dineInBtn;

    @FXML
    private Button drinksBtn;

    @FXML
    private TableColumn<NewOrder, Button> goodDeleteTblClmn;

    @FXML
    private TableColumn<NewOrder, String> goodNameTblClmn;

    @FXML
    private TableColumn<NewOrder, Double> goodPriceTblClmn;

    @FXML
    private TableColumn<NewOrder, Integer> goodQtyTblClmn;

    @FXML
    private GridPane menuGridPane;

    @FXML
    private ScrollPane menuScrollPane;

    @FXML
    private Label orderIDLabel;

    @FXML
    private TableView<NewOrder> orderTableView;

    @FXML
    private Button placeOrderBtn;

    @FXML
    private Button printReceiptBtn;

    @FXML
    private Button sandwichesBtn;

    @FXML
    private TextField searchOrderTextField;

    @FXML
    private Label totalCostLabel;

    private ObservableList<ProductData> cardListData = FXCollections.observableArrayList();
    DBHandler dbHandler = new DBHandler();
    ResultSet resultSet;

    private ObservableList<NewOrder> orderItems;
    @FXML
    void initialize() {
        updateMenuGridPane(burgersBtn.getText());
        updateTotalCostLabel();

        burgersBtn.setOnMouseEntered(event -> {
            burgersBtn.setStyle("-fx-background-color: #ded8d7");
        });

        burgersBtn.setOnMouseExited(event -> {
            burgersBtn.setStyle("-fx-background-color: transparent");
        });

        sandwichesBtn.setOnMouseEntered(event -> {
            sandwichesBtn.setStyle("-fx-background-color: #ded8d7");
        });

        sandwichesBtn.setOnMouseExited(event -> {
            sandwichesBtn.setStyle("-fx-background-color: transparent");
        });

        dessertsBtn.setOnMouseEntered(event -> {
            dessertsBtn.setStyle("-fx-background-color: #ded8d7");
        });

        dessertsBtn.setOnMouseExited(event -> {
            dessertsBtn.setStyle("-fx-background-color: transparent");
        });

        drinksBtn.setOnMouseEntered(event -> {
            drinksBtn.setStyle("-fx-background-color: #ded8d7");
        });

        drinksBtn.setOnMouseExited(event -> {
            drinksBtn.setStyle("-fx-background-color: transparent");
        });

        burgersBtn.setOnAction(event -> {
            burgersBtn.setStyle("-fx-underline: true;");
            updateMenuGridPane(burgersBtn.getText());
        });

        sandwichesBtn.setOnAction(event -> {
            sandwichesBtn.setStyle("-fx-underline: true;");
            updateMenuGridPane(sandwichesBtn.getText());
        });

        dessertsBtn.setOnAction(event -> {
            dessertsBtn.setStyle("-fx-underline: true;");
            updateMenuGridPane(dessertsBtn.getText());
        });

        drinksBtn.setOnAction(event -> {
            drinksBtn.setStyle("-fx-underline: true;");
            updateMenuGridPane(drinksBtn.getText());
        });

        orderItems = FXCollections.observableArrayList();
        orderTableView.setItems(orderItems);

        goodNameTblClmn.setCellValueFactory(new PropertyValueFactory<>("goodName"));
        goodPriceTblClmn.setCellValueFactory(new PropertyValueFactory<>("goodPrice"));
        goodQtyTblClmn.setCellValueFactory(new PropertyValueFactory<>("goodQty"));

        goodDeleteTblClmn.setCellValueFactory(new PropertyValueFactory<>("deleteButton"));
        goodDeleteTblClmn.setCellFactory(DeleteButtonTableCell.forTableColumn());
        // ActionButtonTableCell.forTableColumn("Delete"), (NewOrder orderItem) -> {
    //            orderItems.remove(orderItem);
    //            return orderItem; }

        amountTakenTextField.textProperty().addListener(((observable, oldValue, newValue) -> {
            calculateChange();
        }));

        placeOrderBtn.setOnAction(event -> {
            handlePlaceOrder();
        });

        searchOrderTextField.textProperty().addListener((observable, oldValue, newValue) -> {
            updateMenuGridPaneByName(newValue);
        });
    }

    public void updateMenuGridPane(String typeName) {
        cardListData.clear();
        cardListData.addAll(dbHandler.getProductsByType(typeName));

        menuGridPane.getChildren().clear();

        int row = 0;
        int column = 0;

        menuGridPane.getRowConstraints().clear();
        menuGridPane.getColumnConstraints().clear();

        for (int i = 0; i < cardListData.size(); i++) {

            try {
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("card-product.fxml"));
                AnchorPane pane = loader.load();
                CardProductController cardProductController = loader.getController();
                cardProductController.setMenuPageController(this);
                cardProductController.setProductData(cardListData.get(i));

                cardProductController.setProductSelectionListener(this);

                if (column == 3) {
                    column = 0;
                    row += 1;
                }

                menuGridPane.add(pane, column++, row);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public void updateMenuGridPaneByName(String goodName) {
        cardListData.clear();
        cardListData.addAll(dbHandler.getProductsByName(goodName));

        menuGridPane.getChildren().clear();

        int row = 0;
        int column = 0;

        menuGridPane.getRowConstraints().clear();
        menuGridPane.getColumnConstraints().clear();

        for (int i = 0; i < cardListData.size(); i++) {

            try {
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("card-product.fxml"));
                AnchorPane pane = loader.load();
                CardProductController cardProductController = loader.getController();
                cardProductController.setMenuPageController(this);
                cardProductController.setProductData(cardListData.get(i));

                cardProductController.setProductSelectionListener(this);

                if (column == 3) {
                    column = 0;
                    row += 1;
                }

                menuGridPane.add(pane, column++, row);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onProductSelected(ProductData productData, int quantity) {
        ProductData product = new ProductData(productData.getName(), quantity, productData.getPrice());
        cardListData.add(product);
    }

    private double totalCost;
    public void addToOrder(String goodName, double goodPrice, int goodAmount) {
        Button deleteButton = new Button("Delete");
        NewOrder orderItem = new NewOrder(goodName, goodPrice, goodAmount, deleteButton);
        deleteButton.setOnAction((ActionEvent event) -> {
            orderItems.remove(orderItem);
        });
        orderItems.add(orderItem);

        double itemCost = goodPrice * goodAmount;

        totalCost += itemCost;
        updateTotalCostLabel();
    }

    private void updateTotalCostLabel() {
        totalCostLabel.setText(String.valueOf(totalCost));
    }

    private void calculateChange() {
        try {
            double amountTaken = Double.parseDouble(amountTakenTextField.getText());

            double changeAmount = amountTaken - totalCost;
            changeAmountLabel.setText(String.valueOf(changeAmount));
        } catch (NumberFormatException e) {
            changeAmountLabel.setText("Invalid amount");
        }
    }

    private void handlePlaceOrder() {
        String orderType = getOrderType();
        double totalCost = Double.parseDouble(totalCostLabel.getText());

        int orderID = dbHandler.insertOrder(orderType, totalCost);
        dbHandler.insertOrderItems(orderID, orderItems);

        clearOrder();

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information Message");
        alert.setHeaderText(null);
        alert.setContentText("Заказ успешно добавлен!");
        alert.showAndWait();
    }

    private String getOrderType() {
        if (dineInBtn.isSelected()) {
            return "Здесь";
        } else if (carryOutBtn.isSelected()) {
            return "С собой";
        } else if (deliveryBtn.isSelected()) {
            return "Доставка";
        } else {
            return "";
        }
    }

    private int retrieveOrderID() {
        int orderID = 0;
        String selectQuery = "SELECT LAST_INSERT_ID() AS order_id";

        ResultSet resultSet = null;

        try {
             resultSet = dbHandler.executeQuery(selectQuery);

             if (resultSet.next()) {
                 orderID = resultSet.getInt("order_id");
             }
        } catch (ClassNotFoundException | SQLException e) {
            throw new RuntimeException(e);
        }

        return orderID;
    }

    private void clearOrder() {
        orderItems.clear();
        totalCostLabel.setText("0.00");
        amountTakenTextField.setText("");
        changeAmountLabel.setText("");
    }
}


