package com.example.restaurantis;

import com.example.restaurantis.DBTableClasses.Staff;
import javafx.scene.control.ContentDisplay;
import javafx.scene.control.TableCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.nio.file.Path;
import java.nio.file.Paths;

public class ImageTableCell extends TableCell<Staff, String> {
    private final ImageView imageView;

    public ImageTableCell() {
        this.imageView = new ImageView();
        this.imageView.setFitWidth(50);
        this.imageView.setFitHeight(50);
        setGraphic(imageView);
        setContentDisplay(ContentDisplay.GRAPHIC_ONLY);
    }

    @Override
    protected void updateItem(String imagePath, boolean empty) {
        super.updateItem(imagePath, empty);

        if (empty || imagePath == null) {
            imageView.setImage(null);
        } else {
            String contentRoot = System.getProperty("user.dir");
            Path imagePathResolved = Paths.get(contentRoot, imagePath);

            Image image = new Image(imagePathResolved.toUri().toString());
            imageView.setImage(image);
        }
    }
}

