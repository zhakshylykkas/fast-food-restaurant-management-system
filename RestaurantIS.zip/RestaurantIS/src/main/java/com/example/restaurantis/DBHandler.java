package com.example.restaurantis;

import com.example.restaurantis.DBTableClasses.NewOrder;
import com.example.restaurantis.DBTableClasses.Order;
import com.example.restaurantis.DBTableClasses.OrderGoods;
import com.example.restaurantis.DBTableClasses.Staff;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;

public class DBHandler {
    Connection dbConnection;

    public Connection getDbConnection() throws ClassNotFoundException, SQLException {
        //Class.forName("com.mysql.cj.jdbc.Driver");
        String connectionString = "jdbc:mysql://localhost:3306/restaurant";
        String dbUser = "zhak";
        String dbPassword = "Z!yREsUwLyg(-lri";
        dbConnection = DriverManager.getConnection(connectionString, dbUser, dbPassword);
        return dbConnection;
    }

    public void closeConnection() {
        try {
            if (dbConnection != null && !dbConnection.isClosed()) {
                dbConnection.close();
                System.out.println("Connection closed");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet executeQuery(String query) throws SQLException, ClassNotFoundException {
        Connection connection = getDbConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        return preparedStatement.executeQuery();
    }

    public void closeResultSet(ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public ObservableList<Order> getRecentOrders() throws SQLException, ClassNotFoundException {
        ObservableList<Order> orders = FXCollections.observableArrayList();

        String query = "SELECT * FROM orders ORDER BY order_id DESC LIMIT 10";
        ResultSet resultSet = null;

        try {
            resultSet = executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("order_id");
                String type = resultSet.getString("order_type");
                String customer_name = resultSet.getString("customer_name");
                String deliverer_name = resultSet.getString("deliverer_name");
                String duty_name = resultSet.getString("duty_name");
                Date date = resultSet.getDate("date");
                String status = resultSet.getString("status");
                double totalCost = resultSet.getDouble("total_cost");

                Order order = new Order(id, type, customer_name, deliverer_name, duty_name, date, status, totalCost);
                orders.add(order);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return orders;
    }

    public String getOrderStatus(int orderID) throws SQLException, ClassNotFoundException {
        String query = "SELECT status FROM orders WHERE order_id = ?";

        Connection connection = getDbConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query);

        preparedStatement.setInt(1, orderID);

        ResultSet resultSet = null;
        String orderStatus = null;

        try {
            resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                orderStatus = resultSet.getString("status");
            } else {
                orderStatus = "Заказ не найден";
            }
        } finally {
            closeResultSet(resultSet);
        }

        return orderStatus;
    }

    public int getReceivedOrdersNumber() throws SQLException, ClassNotFoundException {
        String query = "SELECT COUNT(*) FROM orders WHERE status = 'Получен'";
        ResultSet resultSet = null;
        int deliveredOrdersNumber = 0;

        try {
            resultSet = executeQuery(query);

            if (resultSet.next()) {
                deliveredOrdersNumber = resultSet.getInt(1);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return deliveredOrdersNumber;
    }

    public int getProcessingOrdersNumber() throws SQLException, ClassNotFoundException {
        String query = "SELECT COUNT(*) FROM orders WHERE status = 'Готовится'";
        ResultSet resultSet = null;
        int deliveredOrdersNumber = 0;

        try {
            resultSet = executeQuery(query);

            if (resultSet.next()) {
                deliveredOrdersNumber = resultSet.getInt(1);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return deliveredOrdersNumber;
    }

    public int getDeliveredOrdersNumber() throws SQLException, ClassNotFoundException {
        String query = "SELECT COUNT(*) FROM orders WHERE status = 'Доставлен'";
        ResultSet resultSet = null;
        int deliveredOrdersNumber = 0;

        try {
            resultSet = executeQuery(query);

            if (resultSet.next()) {
                deliveredOrdersNumber = resultSet.getInt(1);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return deliveredOrdersNumber;
    }

    public int getServedOrdersNumber() throws SQLException, ClassNotFoundException {
        String query = "SELECT COUNT(*) FROM orders WHERE status = 'Подан'";
        ResultSet resultSet = null;
        int deliveredOrdersNumber = 0;

        try {
            resultSet = executeQuery(query);

            if (resultSet.next()) {
                deliveredOrdersNumber = resultSet.getInt(1);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return deliveredOrdersNumber;
    }

    public int getOrdersNumberForToday() throws SQLException, ClassNotFoundException {
        String query = "SELECT COUNT(*) FROM orders WHERE DATE(date) = CURDATE()";
        ResultSet resultSet = null;
        int deliveredOrdersNumber = 0;

        try {
            resultSet = executeQuery(query);

            if (resultSet.next()) {
                deliveredOrdersNumber = resultSet.getInt(1);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return deliveredOrdersNumber;
    }

    public ObservableList<OrderGoods> getOrderGoods(int orderId) {
        ObservableList<OrderGoods> orderGoodsList = FXCollections.observableArrayList();

        String query = "SELECT * FROM order_goods WHERE order_id = ?";
        ResultSet resultSet = null;

        try {
            PreparedStatement statement = getDbConnection().prepareStatement(query);
            statement.setInt(1, orderId);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int order_id = resultSet.getInt("id");
                String goodName = resultSet.getString("good_name");
                int goodQuantity = resultSet.getInt("good_quantity");
                double goodPrice = resultSet.getDouble("good_price");

                OrderGoods orderGoods = new OrderGoods(id, order_id, goodName, goodQuantity, goodPrice);
                orderGoodsList.add(orderGoods);
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        } finally {
            closeResultSet(resultSet);
        }

        return orderGoodsList;
    }

    public ObservableList<OrderGoods> getOrderDetails() throws SQLException, ClassNotFoundException {
        ObservableList<OrderGoods> orderGoods = FXCollections.observableArrayList();

        String query = "SELECT * FROM order_goods";
        ResultSet resultSet = null;

        try {
            resultSet = executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                int order_id = resultSet.getInt("order_id");
                String good_name = resultSet.getString("good_name");
                int good_quantity = resultSet.getInt("good_quantity");
                double good_price = resultSet.getDouble("good_price");

                OrderGoods orderGood = new OrderGoods(id, order_id, good_name, good_quantity, good_price);
                orderGoods.add(orderGood);
            }
        } finally {
            closeResultSet(resultSet);
        }
        return orderGoods;
    }

    public ObservableList<ProductData> inventoryProductsTable() {
        ObservableList<ProductData> listData = FXCollections.observableArrayList();

        String sql = "SELECT * FROM products";
        ResultSet resultSet = null;

        try {
            resultSet = executeQuery(sql);

            ProductData productData;

            while (resultSet.next()) {
                productData = new ProductData(resultSet.getInt("product_id"),
                        resultSet.getString("product_name"),
                        resultSet.getString("type"),
                        resultSet.getInt("stock"),
                        resultSet.getDouble("price"),
                        resultSet.getString("status"),
                        resultSet.getDate("date"),
                        resultSet.getString("image"));

                listData.add(productData);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return listData;
    }

    public void addNewProduct(int productID, String productName, String type, String stock, String price, String status, String image) {
        String checkProdID = "SELECT product_id FROM products WHERE product_id = '" +
                productID + "'";

        try {
            dbConnection = getDbConnection();
            Statement statement = dbConnection.createStatement();
            ResultSet resultSet = statement.executeQuery(checkProdID);

            if (resultSet.next()) {
                showAlert(Alert.AlertType.ERROR, "Error Message", "Идентификатор " + productID + " уже занят");
            } else {
                String insertData = "INSERT INTO products " +
                        "(product_id, product_name, type, stock, price, status, date, image) " +
                        "VALUES(?,?,?,?,?,?,?,?)";

                //Connection connection = getDbConnection();
                PreparedStatement preparedStatement = dbConnection.prepareStatement(insertData);

                preparedStatement.setInt(1, productID);
                preparedStatement.setString(2, productName);
                preparedStatement.setString(3, type);
                preparedStatement.setString(4, stock);
                preparedStatement.setString(5, price);
                preparedStatement.setString(6, status);

                LocalDate currentDate = LocalDate.now();
                //java.sql.Date sqlDate = new java.sql.Date();
                preparedStatement.setDate(7, Date.valueOf(currentDate));

                preparedStatement.setString(8, image);

                preparedStatement.executeUpdate();

                showAlert(Alert.AlertType.INFORMATION, "Error Message", "Успешно добавлено!");


            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void updateProduct(int productID, String productName, String type, String stock, String price, String status) {
        LocalDate currentDate = LocalDate.now();

        String updateData = "UPDATE products SET " +
                //"product_id = '" + productID + "', " +
                "product_name = '" + productName + "', " +
                "type = '" + type + "', " +
                "stock = '" + stock + "', " +
                "price = '" + price + "', " +
                "status = '" + status + "', " +
                "date = '" + currentDate + "' " +
                "WHERE product_id = " + productID;

        PreparedStatement preparedStatement = null;

        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Error Messaage");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to UPDATE Product ID: " + productID + "?");

            Optional<ButtonType> option = alert.showAndWait();

            if (option.get().equals(ButtonType.OK)) {
                preparedStatement = dbConnection.prepareStatement(updateData);
                preparedStatement.executeUpdate();

                showAlert(Alert.AlertType.INFORMATION, "Error Messaage", "Successfully updated!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error Messaage", "Canceled.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteProduct(int productID, String productName, String type, String stock, String price, String status) {
        String deleteData = "DELETE FROM products WHERE product_id = " + productID;
        PreparedStatement preparedStatement = null;

        try {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Error Messaage");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure to DELETE Product ID: " + productID + "?");

            Optional<ButtonType> option = alert.showAndWait();

            if (option.get().equals(ButtonType.OK)) {
                preparedStatement = dbConnection.prepareStatement(deleteData);
                preparedStatement.executeUpdate();

                showAlert(Alert.AlertType.INFORMATION, "Error Messaage", "Successfully deleted!");
            } else {
                showAlert(Alert.AlertType.ERROR, "Error Messaage", "Canceled.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ObservableList<ProductData> getProductsByType(String type) {
        String query = "SELECT * FROM products WHERE type = '" + type + "'";

        ObservableList<ProductData> productListByType = FXCollections.observableArrayList();
        ResultSet resultSet;

        try {
            resultSet = executeQuery(query);

            ProductData productData;

            while (resultSet.next()) {
                productData = new ProductData(//resultSet.getInt("product_id"),
                        resultSet.getString("product_name"),
                        resultSet.getDouble("price"),
                        resultSet.getString("image")
                );

                productListByType.add(productData);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return productListByType;
    }

    public int insertOrder(String orderType, double totalCost) {
        String insertQuery = "INSERT INTO orders (order_type, customer_name, duty_name, status, date, total_cost) VALUES (?, ?, ?, ?, ?, ?, ?)";
        int orderId = 0;

        try (Connection connection = getDbConnection();
             PreparedStatement statement = connection.prepareStatement(insertQuery, PreparedStatement.RETURN_GENERATED_KEYS)) {
             statement.setString(1, orderType);
             statement.setString(2, "Не указано");
             statement.setString(3, "Жакшылык Касымбеков");
             statement.setString(4, "Не указано");
             statement.setString(5, "Получен");
             statement.setDouble(7, totalCost);
             statement.setDate(6, java.sql.Date.valueOf(LocalDate.now()));

             statement.executeUpdate();

             ResultSet generatedKeys = statement.getGeneratedKeys();
             if (generatedKeys.next()) {
                 orderId = generatedKeys.getInt(1);
             }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return orderId;
    }

    public void insertOrderItems(int orderId, ObservableList<NewOrder> orderItems) {
        String insertQuery = "INSERT INTO order_goods (order_id, good_name, good_quantity, good_price) VALUES (?, ?, ?, ?)";

        try (Connection connection = getDbConnection();
             PreparedStatement statement = connection.prepareStatement(insertQuery)) {
            for (NewOrder orderItem : orderItems) {
                statement.setInt(1, orderId);
                statement.setString(2, orderItem.getGoodName());
                statement.setDouble(3, orderItem.getGoodPrice());
                statement.setInt(4, orderItem.getGoodQty());

                statement.executeUpdate();
                //statement.addBatch();
            }

            statement.executeBatch();
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public ObservableList<ProductData> getProductsByName(String goodName) {
        String query = "SELECT * FROM products WHERE product_name = '" + goodName + "'";

        ObservableList<ProductData> productListByType = FXCollections.observableArrayList();
        ResultSet resultSet;

        try {
            resultSet = executeQuery(query);

            ProductData productData;

            while (resultSet.next()) {
                productData = new ProductData(//resultSet.getInt("product_id"),
                        resultSet.getString("product_name"),
                        resultSet.getDouble("price"),
                        resultSet.getString("image")
                );

                productListByType.add(productData);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        } finally {
            closeConnection();
        }

        return productListByType;
    }

    public ObservableList<Staff> getAllStaff() {
        ObservableList<Staff> staffList = FXCollections.observableArrayList();

        String selectQuery = "SELECT * FROM staff";

        try (Connection connection = getDbConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(selectQuery)) {

            while (resultSet.next()) {
                int staffID = resultSet.getInt("staff_id");
                String staffName = resultSet.getString("staff_fullname");
                String staffRole = resultSet.getString("staff_role");
                String phoneNumber = resultSet.getString("phone_number");
                String email = resultSet.getString("email");
                String photo = resultSet.getString("photo");

                Staff staff = new Staff(staffID, staffName, staffRole, phoneNumber, email, photo);
                staffList.add(staff);
            }
        } catch (SQLException | ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return staffList;
    }
}
