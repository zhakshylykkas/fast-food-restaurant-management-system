package com.example.restaurantis.DBTableClasses;

import com.example.restaurantis.DBHandler;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class OrderDetailsTableView {
    private final TableView<OrderGoods> orderGoodsTableView;
    DBHandler dbHandler = new DBHandler();

    public OrderDetailsTableView(TableView<OrderGoods> orderGoodsTableView) {
        this.orderGoodsTableView = orderGoodsTableView;
    }

    public void createTableColumnAndSetCellValueFactories(int orderID) {
        TableColumn<OrderGoods, String> goodNameColumn = new TableColumn<>("Название продукта");
        TableColumn<OrderGoods, Integer> goodQtyColumn = new TableColumn<>("К-во");
        TableColumn<OrderGoods, Double> goodPriceColumn = new TableColumn<>("Цена");

        goodNameColumn.setCellValueFactory(new PropertyValueFactory<>("goodName"));
        goodQtyColumn.setCellValueFactory(new PropertyValueFactory<>("goodQty"));
        goodPriceColumn.setCellValueFactory(new PropertyValueFactory<>("goodPrice"));

        orderGoodsTableView.getColumns().addAll(goodNameColumn, goodQtyColumn, goodPriceColumn);

        ObservableList<OrderGoods> orderGoods = dbHandler.getOrderGoods(orderID);
        orderGoodsTableView.setItems(orderGoods);
    }
}
