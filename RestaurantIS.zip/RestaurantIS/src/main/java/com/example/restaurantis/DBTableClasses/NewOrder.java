package com.example.restaurantis.DBTableClasses;

import javafx.beans.property.*;
import javafx.scene.control.Button;

public class NewOrder {
    private String goodName;
    private double goodPrice;
    private int goodQty;
    private Button deleteButton;

    public NewOrder(String goodName, double goodPrice, int goodQty, Button deleteButton) {
        this.goodName = goodName;
        this.goodPrice = goodPrice;
        this.goodQty = goodQty;
        this.deleteButton = deleteButton;
    }

    public Button getDeleteButton() {
        return deleteButton;
    }
    public String getGoodName() {
        return goodName;
    }

    public double getGoodPrice() {
        return goodPrice;
    }

    public int getGoodQty() {
        return goodQty;
    }

    public StringProperty goodNameProperty() {
        return new SimpleStringProperty(goodName);
    }

    public IntegerProperty goodQtyProperty() {
        return new SimpleIntegerProperty(goodQty);
    }

    public DoubleProperty goodPriceProperty() {
        return new SimpleDoubleProperty(goodPrice);
    }
}

