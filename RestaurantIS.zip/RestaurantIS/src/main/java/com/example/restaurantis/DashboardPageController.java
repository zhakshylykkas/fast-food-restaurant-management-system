package com.example.restaurantis;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.example.restaurantis.DBTableClasses.Order;
import com.example.restaurantis.DBTableClasses.OrderDetailsTableView;
import com.example.restaurantis.DBTableClasses.OrderGoods;
import com.example.restaurantis.DBTableClasses.OrderTableView;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;

public class DashboardPageController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane dashboardAnchorPane;

    @FXML
    private Label deliveredOrdersLabel;

    @FXML
    private TableView<OrderGoods> orderDetailsTableView;

    @FXML
    private Label orderStatusLabel;

    @FXML
    private Label processingOrdersLabel;

    @FXML
    private Label receivedOrdersLabel;

    @FXML
    private TableView<Order> recentOrdersTableView;

    @FXML
    private TextField searchOrderTextField;

    @FXML
    private Label servedOrdersLabel;

    DBHandler dbHandler = new DBHandler();

    @FXML
    void initialize() {
        updateOrderInfoBlocks();
        updateOrderTableView();

        searchOrderTextField.setOnAction(event -> {
            try {
                int inputOrderID = Integer.parseInt(searchOrderTextField.getText());
                String orderStatus = dbHandler.getOrderStatus(inputOrderID);
                orderStatusLabel.setText(orderStatus);
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            } catch (NumberFormatException e) {
                orderStatusLabel.setText("Введите правильный номер заказа");
            }

            orderStatusLabel.setStyle("-fx-font-weight: bold");
        });

        recentOrdersTableView.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            orderDetailsTableView.getItems().clear();
            if (newSelection != null) {
                orderDetailsTableView.getItems().clear();
                Order selectedOrder = newSelection;
                int orderID = selectedOrder.getId();
                updateOrderDetailsTableView(orderID);
            }
        });
    }

    public void updateOrderInfoBlocks() {
        try {
            deliveredOrdersLabel.setText("+" + dbHandler.getDeliveredOrdersNumber());
            //receivedOrdersLabel.setText("+" + dbHandler.getReceivedOrdersNumber());
            processingOrdersLabel.setText("+" + dbHandler.getProcessingOrdersNumber());
            servedOrdersLabel.setText("+" + dbHandler.getServedOrdersNumber());
            receivedOrdersLabel.setText("+" + dbHandler.getOrdersNumberForToday());
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void updateOrderTableView() {
        OrderTableView orderTableView = new OrderTableView(recentOrdersTableView);
        orderTableView.createTableColumnAndSetCellValueFactories();
    }

    public void updateOrderDetailsTableView(int orderID) {
        OrderDetailsTableView orderDetailsTableView1 = new OrderDetailsTableView(orderDetailsTableView);
        orderDetailsTableView1.createTableColumnAndSetCellValueFactories(orderID);
    }
}

