package com.example.restaurantis.DBTableClasses;

import javafx.scene.control.Button;

public class Staff {
    private int staffID;
    private String staffName;
    private String staffRole;
    private String phoneNumber;
    private String email;
    private String photo;

    public Staff(int staffID, String staffName, String staffRole, String phoneNumber, String email, String photo) {
        this.staffID = staffID;
        this.staffName = staffName;
        this.staffRole = staffRole;
        this.phoneNumber = phoneNumber;
        this.email = email;
        this.photo = photo;
    }

    public int getStaffID() {
        return staffID;
    }

    public void setStaffID(int staffID) {
        this.staffID = staffID;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public String getStaffRole() {
        return staffRole;
    }

    public void setStaffRole(String staffRole) {
        this.staffRole = staffRole;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }
}

