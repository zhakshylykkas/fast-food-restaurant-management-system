package com.example.restaurantis;

import java.util.Date;

public class ProductData {

    private Integer id;
    private String name;
    private String type;
    private Integer stock;
    private Double price;
    private String status;
    private Date date;
    private String image;

    public ProductData(Integer id, String name, String type, Integer stock, Double price, String status, Date date, String image) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.stock = stock;
        this.price = price;
        this.status = status;
        this.date = date;
        this.image = image;
    }

    public ProductData(String name, Double price, String image) {
        this.name = name;
        this.price = price;
        this.image = image;
    }

    public ProductData(String name, Integer stock, Double price) {
        this.name = name;
        this.stock = stock;
        this.price = price;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public Integer getStock() {
        return stock;
    }

    public Double getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    public Date getDate() {
        return date;
    }

    public String getImage() {
        return image;
    }
}
