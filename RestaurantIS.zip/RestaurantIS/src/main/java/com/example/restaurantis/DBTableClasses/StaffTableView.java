package com.example.restaurantis.DBTableClasses;

import com.example.restaurantis.DBHandler;
import com.example.restaurantis.ImageTableCell;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class StaffTableView {
    private final TableView<Staff> staffTableView;
    DBHandler dbHandler = new DBHandler();
    public StaffTableView(TableView<Staff> staffTableView) {
        this.staffTableView = staffTableView;
    }

    public void createTableColumnAndSetCellValueFactories() {
        staffTableView.getColumns().clear();

        TableColumn<Staff, String> photoColumn = new TableColumn<>("Фото");
        TableColumn<Staff, String> fullNameColumn = new TableColumn<>("ФИО сотрудника");
        TableColumn<Staff, String> staffRoleColumn = new TableColumn<>("Должность");
        TableColumn<Staff, String> phoneNumberColumn = new TableColumn<>("Номер телефона");
        TableColumn<Staff, String> emailColumn = new TableColumn<>("Email");

        photoColumn.setCellValueFactory(new PropertyValueFactory<>("photo"));
        photoColumn.setCellFactory(param -> new ImageTableCell());

        fullNameColumn.setCellValueFactory(new PropertyValueFactory<>("staffName"));
        staffRoleColumn.setCellValueFactory(new PropertyValueFactory<>("staffRole"));
        phoneNumberColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));


//        TableColumn<Staff, String> staffDeleteTblClmn = new TableColumn<>("Удалить");
//        staffDeleteTblClmn.setCellValueFactory(new PropertyValueFactory<>("deleteButton"));
//        staffDeleteTblClmn.setCellFactory(DeleteButtonTableCell.forTableColumn());
//
//        TableColumn<Staff, String> staffEditTblClmn = new TableColumn<>("Редактировать");
//        staffEditTblClmn.setCellValueFactory(new PropertyValueFactory<>("editButton"));
//        staffEditTblClmn.setCellFactory(DeleteButtonTableCell.forTableColumn());

        staffTableView.getColumns().addAll(photoColumn, fullNameColumn, staffRoleColumn,
                phoneNumberColumn, emailColumn); //, staffEditTblClmn, staffDeleteTblClmn

        ObservableList<Staff> staff = dbHandler.getAllStaff();
        staffTableView.setItems(staff);
    }
}
