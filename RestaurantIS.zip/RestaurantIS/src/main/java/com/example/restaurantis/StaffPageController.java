package com.example.restaurantis;

import java.net.URL;
import java.util.ResourceBundle;

import com.example.restaurantis.DBTableClasses.Staff;
import com.example.restaurantis.DBTableClasses.StaffTableView;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class StaffPageController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<?, ?> emailTableClmn;

    @FXML
    private TableView<Staff> staffTableView;

    @FXML
    private TableColumn<?, ?> phoneNumberTableClmn;

    @FXML
    private Button resetButton;

    @FXML
    private TextField searchStaffTextField;

    @FXML
    private Button sortOrdersButton;

    @FXML
    private TableColumn<?, ?> staffFullNameTableClmn;

    @FXML
    private TableColumn<?, ?> staffPhotoTableClmn;

    @FXML
    private MenuButton staffRoleMenuButton;

    @FXML
    private TableColumn<?, ?> staffRoleTableClmn;

    @FXML
    void initialize() {
        updateStaffTableView();
        setItemsToStaffRoleMenuButton();

        sortOrdersButton.setOnAction(event -> searchStaffMembers());

        resetButton.setOnAction(event -> {
            searchStaffTextField.setText(null);
            staffRoleMenuButton.setText("Выберите должность");
            updateStaffTableView();
        });
    }

    public void updateStaffTableView() {
        StaffTableView staffTableView1 = new StaffTableView(staffTableView);
        staffTableView1.createTableColumnAndSetCellValueFactories();
    }

    public void searchStaffMembers() {
        String searchText = searchStaffTextField.getText();
        String selectedRole = staffRoleMenuButton.getText();

        FilteredList<Staff> filteredList = new FilteredList<>(staffTableView.getItems());

        filteredList.setPredicate(staff -> {
            boolean matchesSearchText = staff.getStaffName().toLowerCase().contains(searchText.toLowerCase());

            boolean matchesRole = selectedRole.equals("Выберите должность") || staff.getStaffRole().equals(selectedRole);

            return matchesSearchText && matchesRole;
        });

        SortedList<Staff> sortedList = new SortedList<>(filteredList);
        sortedList.comparatorProperty().bind(staffTableView.comparatorProperty());

        staffTableView.setItems(sortedList);
    }

    public void setItemsToStaffRoleMenuButton() {
        staffRoleMenuButton.getItems().clear();

        MenuItem menuItem1 = new MenuItem("Администратор");
        MenuItem menuItem2 = new MenuItem("Официант");
        MenuItem menuItem3 = new MenuItem("Шеф повар");
        MenuItem menuItem4 = new MenuItem("Охранник");

        staffRoleMenuButton.getItems().addAll(menuItem1, menuItem2, menuItem3, menuItem4);

        menuItem1.setOnAction(event -> {
            String selectedStatus = menuItem1.getText();
            staffRoleMenuButton.setText(selectedStatus);
        });

        menuItem2.setOnAction(event -> {
            String selectedStatus = menuItem2.getText();
            staffRoleMenuButton.setText(selectedStatus);
        });

        menuItem3.setOnAction(event -> {
            String selectedStatus = menuItem3.getText();
            staffRoleMenuButton.setText(selectedStatus);
        });

        menuItem4.setOnAction(event -> {
            String selectedStatus = menuItem4.getText();
            staffRoleMenuButton.setText(selectedStatus);
        });
    }
}

