package com.example.restaurantis.DBTableClasses;

public class OrderGoods {
    private int id;
    private int order_id;
    private String goodName;
    private int goodQty;
    private double goodPrice;

    public OrderGoods(int id, int order_id, String goodName, int goodQty, double goodPrice) {
        this.id = id;
        this.order_id = order_id;
        this.goodName = goodName;
        this.goodQty = goodQty;
        this.goodPrice = goodPrice;
    }

    public OrderGoods(String goodName, int goodQty, double goodPrice) {
        this.goodName = goodName;
        this.goodQty = goodQty;
        this.goodPrice = goodPrice;
    }

    public int getId() {
        return id;
    }

    public int getOrder_id() {
        return order_id;
    }

    public String getGoodName() {
        return goodName;
    }

    public int getGoodQty() {
        return goodQty;
    }

    public double getGoodPrice() {
        return goodPrice;
    }
}
