package com.example.restaurantis;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.util.Callback;

public class DeleteButtonTableCell<S> extends TableCell<S, Button> {
    private final Button deleteButton;

    public DeleteButtonTableCell() {
        this.deleteButton = new Button("Удалить");
        this.deleteButton.setOnAction((ActionEvent event) -> {
            if (getTableRow() != null) {
                getTableView().getItems().remove(getTableRow().getIndex());
            }
        });
    }

    @Override
    protected void updateItem(Button item, boolean empty) {
        super.updateItem(item, empty);

        if (empty || item == null) {
            setGraphic(null);
        } else {
            setGraphic(deleteButton);
        }
    }

    public static <S> Callback<TableColumn<S, Button>, TableCell<S, Button>> forTableColumn() {
        return param -> new DeleteButtonTableCell<>();
    }
}
