package com.example.restaurantis;

import java.net.URL;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.ResourceBundle;

import com.example.restaurantis.DBTableClasses.Order;
import com.example.restaurantis.DBTableClasses.OrderTableView;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.scene.control.*;

public class OrdersHistoryPageController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<?, ?> customerNameTableClmn;

    @FXML
    private TableColumn<?, ?> delivererNameTableClmn;

    @FXML
    private TableColumn<?, ?> dutyNameTableClmn;

    @FXML
    private DatePicker fromDatePicker;

    @FXML
    private TableColumn<?, ?> orderDateTableClmn;

    @FXML
    private TableColumn<?, ?> orderIDTableClmn;

    @FXML
    private TableColumn<?, ?> orderStatusTableClmn;

    @FXML
    private TableColumn<?, ?> orderTypeTableClmn;

    @FXML
    private TableView<Order> ordersTableView;

    @FXML
    private Button resetButton;

    @FXML
    private TextField searchOrderTextField;

    @FXML
    private Button sortOrdersButton;

    @FXML
    private MenuButton statusMenuButton;

    @FXML
    private DatePicker toDatePicker;

    @FXML
    private TableColumn<?, ?> totalCostTableClmn;

    @FXML
    void initialize() {
        updateOrdersTableView();
        setItemsToStatusMenuButton();

        sortOrdersButton.setOnAction(event -> {
            updateOrdersTableView();

            String searchOrderText = searchOrderTextField.getText();
            String status = statusMenuButton.getText();
            LocalDate fromDate = fromDatePicker.getValue();
            LocalDate toDate = toDatePicker.getValue();

//            ObservableList<Order> items = ordersTableView.getItems();

            FilteredList<Order> filteredList = new FilteredList<>(ordersTableView.getItems());

            filteredList.setPredicate(order -> {
                boolean matchesSearchText = searchOrderText == null
                        || String.valueOf(order.getId()).contains(searchOrderText)
                        || order.getType().toLowerCase().contains(searchOrderText)
                        || (order.getCustomerName() != null && order.getCustomerName().toLowerCase().contains(searchOrderText))
                        || (order.getDelivererName() != null && order.getDelivererName().toLowerCase().contains(searchOrderText))
                        || order.getDutyName().toLowerCase().contains(searchOrderText);

//                boolean matchesSearchText = true;
//                if (searchOrderText != null && !searchOrderText.isEmpty()) {
//                    matchesSearchText = String.valueOf(order.getId()).contains(searchOrderText)
//                            || order.getType().toLowerCase().contains(searchOrderText)
//                            || order.getCustomerName().toLowerCase().contains(searchOrderText)
//                            || (order.getDelivererName() != null && order.getDelivererName().toLowerCase().contains(searchOrderText))
//                            || order.getDutyName().toLowerCase().contains(searchOrderText);
//                }

                boolean matchesStatus = status.equals("Выберите статус...") || order.getStatus().equals(status); //null || status.isEmpty()
//                boolean matchesStatus = true;
//                if (status.equals("Выберите статус...")) {
//                    matchesStatus = order.getStatus().equals(status);
//                }


//                boolean matchesDateRange = fromDate == null && toDate == null
//                        || (fromDate != null && toDate == null && order.getDate().after(java.sql.Date.valueOf(fromDate)))
//                        || (fromDate == null && toDate != null && order.getDate().before(java.sql.Date.valueOf(toDate)))
//                        || (fromDate != null && toDate != null && order.getDate().after(java.sql.Date.valueOf(fromDate))
//                        && order.getDate().before(java.sql.Date.valueOf(toDate)));

                boolean matchesDateRange = true;
                if (fromDate != null) {
                    Instant fromInstant = fromDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
                    Date fromDateObj = Date.from(fromInstant);
                    matchesDateRange = order.getDate().after(fromDateObj) || order.getDate().equals(fromDateObj);
                }

                if (toDate != null) {
                    Instant toInstant = toDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
                    Date toDateObj = Date.from(toInstant);
                    matchesDateRange = matchesDateRange && (order.getDate().before(toDateObj) || order.getDate().equals(toDateObj));
                }

//                boolean matchesDateRange = true;
//                if (fromDate != null && toDate != null) {
//                    Instant fromInstant = fromDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
//                    Date fromDateObj = Date.from(fromInstant);
//
//                    Instant toInstant = toDate.atStartOfDay(ZoneId.systemDefault()).toInstant();
//                    Date toDateObj = Date.from(toInstant);
//
//                    matchesDateRange = order.getDate().after(fromDateObj) || order.getDate().equals(fromDateObj);
//                    matchesDateRange = matchesDateRange && (order.getDate().before(toDateObj) || order.getDate().equals(toDateObj));
//                }

                return matchesSearchText && matchesStatus && matchesDateRange;
            });

            SortedList<Order> sortedList = new SortedList<>(filteredList);
            sortedList.comparatorProperty().bind(ordersTableView.comparatorProperty());

            ordersTableView.setItems(filteredList);
        });

        resetButton.setOnAction(event -> {
            searchOrderTextField.setText(null);
            statusMenuButton.setText("Выберите статус...");
            fromDatePicker.setValue(null);
            toDatePicker.setValue(null);
            updateOrdersTableView();
        });

        sortOrdersButton.setOnMouseEntered(event -> {
            sortOrdersButton.setStyle("-fx-background-color: #ff8c00; -fx-effect: dropshadow(gaussian, rgba(0, 0, 0, 0.2), 10, 0, 0, 2);");
        });

        sortOrdersButton.setOnMouseExited(event -> {
            sortOrdersButton.setStyle("-fx-background-color: #ff8c00;");
        });
    }
    public void updateOrdersTableView() {
        OrderTableView orderTableView = new OrderTableView(ordersTableView);
        orderTableView.createTableColumnAndSetCellValueFactories();
    }

    public void setItemsToStatusMenuButton() {
        statusMenuButton.getItems().clear();

        MenuItem menuItem1 = new MenuItem("Получен");
        MenuItem menuItem2 = new MenuItem("Подан");
        MenuItem menuItem3 = new MenuItem("Готовится");
        MenuItem menuItem4 = new MenuItem("Доставлен");

        statusMenuButton.getItems().addAll(menuItem1, menuItem2, menuItem3, menuItem4);

        menuItem1.setOnAction(event -> {
            String selectedStatus = menuItem1.getText();
            statusMenuButton.setText(selectedStatus);
        });

        menuItem2.setOnAction(event -> {
            String selectedStatus = menuItem2.getText();
            statusMenuButton.setText(selectedStatus);
        });

        menuItem3.setOnAction(event -> {
            String selectedStatus = menuItem3.getText();
            statusMenuButton.setText(selectedStatus);
        });

        menuItem4.setOnAction(event -> {
            String selectedStatus = menuItem4.getText();
            statusMenuButton.setText(selectedStatus);
        });
    }
}

