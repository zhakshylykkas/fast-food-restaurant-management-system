package com.example.restaurantis;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import com.example.restaurantis.DBTableClasses.NewOrder;
import com.example.restaurantis.DBTableClasses.NewOrderTableView;
import com.example.restaurantis.DBTableClasses.OrderGoods;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class CardProductController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane cardForm;

    @FXML
    private Button goodAddButton;

    @FXML
    private Spinner<Integer> goodAmountSpinner;

    @FXML
    private ImageView goodImageView;

    @FXML
    private Label goodName;

    @FXML
    private Label goodPrice;

    private ProductData productData;
    private Image image;

    private MenuPageController menuPageController;
    public void setMenuPageController(MenuPageController menuPageController) {
        this.menuPageController = menuPageController;
    }

    @FXML
    void initialize() {
        setGoodQuantityOrder();
        goodAddButton.setOnAction(event -> {
            String productName = goodName.getText();
            double price = Double.parseDouble(goodPrice.getText());
            int quantity = goodAmountSpinner.getValue();

            if (quantity != 0) {
                menuPageController.addToOrder(productName, price, quantity);
            }
        });
    }

    public void setProductData(ProductData productData) {
        this.productData = productData;

        goodName.setText(productData.getName());
        goodPrice.setText(String.valueOf(productData.getPrice()));
        String path = productData.getImage(); //"File: " +
        image = new Image(new File(path).toURI().toString()); //, 120, 80, false, true
        goodImageView.setImage(image);
    }

    public void setGoodQuantityOrder() {
        SpinnerValueFactory<Integer> spinnerValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(0, 100, 0);
        goodAmountSpinner.setValueFactory(spinnerValueFactory);
    }

    private ProductSelectionListener productSelectionListener;
    public interface ProductSelectionListener {
        void onProductSelected(ProductData product, int quantity);
    }
    public void setProductSelectionListener(ProductSelectionListener listener) {
        this.productSelectionListener = listener;
    }
}

