package com.example.restaurantis.DBTableClasses;

import com.example.restaurantis.DBHandler;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.SQLException;

public class OrderTableView {
    private final TableView<Order> orderTableView;
    DBHandler dbHandler = new DBHandler();

    public OrderTableView(TableView<Order> orderTableView) {
        this.orderTableView = orderTableView;
    }

    public void createTableColumnAndSetCellValueFactories() {
        orderTableView.getColumns().clear();

        TableColumn<Order, Integer> idColumn = new TableColumn<>("Номер");
        TableColumn<Order, String> typeColumn = new TableColumn<>("Тип заказа");
        TableColumn<Order, String> customerNameColumn = new TableColumn<>("Заказчик");
        TableColumn<Order, String> delivererNameColumn = new TableColumn<>("Доставщик");
        TableColumn<Order, String> dutyNameColumn = new TableColumn<>("Сотрудник");
        TableColumn<Order, String> dateColumn = new TableColumn<>("Дата");
        TableColumn<Order, String> statusColumn = new TableColumn<>("Статус");
        TableColumn<Order, Double> totalCost = new TableColumn<>("Общая стоимость");

        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        typeColumn.setCellValueFactory(new PropertyValueFactory<>("type"));
        customerNameColumn.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        delivererNameColumn.setCellValueFactory(new PropertyValueFactory<>("delivererName"));
        dutyNameColumn.setCellValueFactory(new PropertyValueFactory<>("dutyName"));
        dateColumn.setCellValueFactory(new PropertyValueFactory<>("date"));
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));
        totalCost.setCellValueFactory(new PropertyValueFactory<>("totalCost"));

        orderTableView.getColumns().addAll(idColumn, typeColumn, customerNameColumn,
                delivererNameColumn, dutyNameColumn, dateColumn, statusColumn, totalCost);

        try {
            ObservableList<Order> orders = dbHandler.getRecentOrders();
            orderTableView.setItems(orders);
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
