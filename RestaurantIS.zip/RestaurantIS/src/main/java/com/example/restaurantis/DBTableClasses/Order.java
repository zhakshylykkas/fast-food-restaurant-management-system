package com.example.restaurantis.DBTableClasses;

import java.util.Date;

public class Order {
    private int id;
    private String type;
    private String customerName;
    private String delivererName;
    private String dutyName;
    private Date date;
    private String status;
    private double totalCost;

    public Order(int id, String type, String customerName, String delivererName, String dutyName, Date date, String status, double totalCost) {
        this.id = id;
        this.type = type;
        this.customerName = customerName;
        this.delivererName = delivererName;
        this.dutyName = dutyName;
        this.date = date;
        this.status = status;
        this.totalCost = totalCost;
    }

    public int getId() {
        return id;
    }

    public String getType() {
        return type;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getDutyName() {
        return dutyName;
    }

    public Date getDate() {
        return date;
    }

    public String getDelivererName() {
        return delivererName;
    }


    public String getStatus() {
        return status;
    }

    public double getTotalCost() {
        return totalCost;
    }
}
