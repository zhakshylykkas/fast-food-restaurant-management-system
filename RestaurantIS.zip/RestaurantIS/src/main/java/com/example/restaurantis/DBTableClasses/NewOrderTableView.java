package com.example.restaurantis.DBTableClasses;

import com.example.restaurantis.CardProductController;
import com.example.restaurantis.DBHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class NewOrderTableView {
    private TableView<NewOrder> newOrderTableView;
    private ObservableList<NewOrder> orderItems;
    public NewOrderTableView(TableView<NewOrder> newOrderTableView) {
        this.newOrderTableView = newOrderTableView;
    }

    public void createTableColumnAndSetCellValueFactories() {
        newOrderTableView = new TableView<>();
        TableColumn<NewOrder, String> goodNameColumn = new TableColumn<>("Название продукта");
        TableColumn<NewOrder, Integer> goodQtyColumn = new TableColumn<>("К-во");
        TableColumn<NewOrder, Double> goodPriceColumn = new TableColumn<>("Цена");

        goodNameColumn.setCellValueFactory(data -> data.getValue().goodNameProperty()); //new PropertyValueFactory<>("goodName")
        goodQtyColumn.setCellValueFactory(data -> data.getValue().goodQtyProperty().asObject());
        goodPriceColumn.setCellValueFactory(data -> data.getValue().goodPriceProperty().asObject());

        newOrderTableView.getColumns().addAll(goodNameColumn, goodPriceColumn, goodQtyColumn);

        orderItems = FXCollections.observableArrayList();
        newOrderTableView.setItems(orderItems);
    }
}
