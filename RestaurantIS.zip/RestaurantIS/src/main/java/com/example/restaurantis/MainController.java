package com.example.restaurantis;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ResourceBundle;

import com.example.restaurantis.DBTableClasses.Order;
import com.example.restaurantis.DBTableClasses.OrderTableView;
import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

public class MainController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button accountButton;

    @FXML
    private VBox contentPaneVBox;

    @FXML
    private Button dashboardButton;

    @FXML
    private Label dateAndTimeLabel;

    @FXML
    private Button exitButton;

    @FXML
    private Button inventoryPageButton;

    @FXML
    private Button logoutButton;

    @FXML
    private AnchorPane mainContentAnchorPane;

    @FXML
    private ImageView menuList;

    @FXML
    private AnchorPane menuListAnchorPane;

    @FXML
    private Button menuPageButton;

    @FXML
    private Button ordersHistoryPageButton;

    @FXML
    private Button staffPageButton;

    @FXML
    void initialize() {
        updateMainContent("dashboard-page.fxml");

        Timeline timeline = new Timeline(new KeyFrame(Duration.seconds(1), event -> updateDateTime()));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();

        logoutButton.setOnAction(event -> {
            logoutButton.getScene().getWindow().hide();

            try {
                openNewScene("login-page.fxml");
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        dashboardButton.setOnAction(event -> {
            updateMainContent("dashboard-page.fxml");
        });

        menuPageButton.setOnAction(event -> {
            updateMainContent("menu-page.fxml");
        });

        inventoryPageButton.setOnAction(event -> {
            updateMainContent("inventory-page.fxml");
        });

        ordersHistoryPageButton.setOnAction(event -> {
            updateMainContent("orders-history-page.fxml");
        });

        staffPageButton.setOnAction(event -> {
            updateMainContent("staff-page.fxml");
        });

        exitButton.setOnAction(event -> {
            Stage stage = (Stage) exitButton.getScene().getWindow();
            stage.close();
        });

        dashboardButton.setOnMouseEntered(event -> {
            dashboardButton.setStyle("-fx-background-color: #0d47a1");
        });

        dashboardButton.setOnMouseExited(event -> {
            dashboardButton.setStyle("-fx-background-color: #050e52");
        });

        ordersHistoryPageButton.setOnMouseEntered(event -> {
            ordersHistoryPageButton.setStyle("-fx-background-color: #0d47a1");
        });

        ordersHistoryPageButton.setOnMouseExited(event -> {
            ordersHistoryPageButton.setStyle("-fx-background-color: #050e52");
        });

        menuPageButton.setOnMouseEntered(event -> {
            menuPageButton.setStyle("-fx-background-color: #0d47a1");
        });

        menuPageButton.setOnMouseExited(event -> {
            menuPageButton.setStyle("-fx-background-color: #050e52");
        });

        staffPageButton.setOnMouseEntered(event -> {
            staffPageButton.setStyle("-fx-background-color: #0d47a1");
        });

        staffPageButton.setOnMouseExited(event -> {
            staffPageButton.setStyle("-fx-background-color: #050e52");
        });

        inventoryPageButton.setOnMouseEntered(event -> {
            inventoryPageButton.setStyle("-fx-background-color: #0d47a1");
        });

        inventoryPageButton.setOnMouseExited(event -> {
            inventoryPageButton.setStyle("-fx-background-color: #050e52");
        });

        accountButton.setOnMouseEntered(event -> {
            accountButton.setStyle("-fx-background-color: #0d47a1");
        });

        accountButton.setOnMouseExited(event -> {
            accountButton.setStyle("-fx-background-color: #050e52");
        });

        //#ded8d7
        logoutButton.setOnMouseEntered(event -> {
            logoutButton.setStyle("-fx-background-color: #0d47a1");
        });

        logoutButton.setOnMouseExited(event -> {
            logoutButton.setStyle("-fx-background-color: #050e52");
        });

        accountButton.setOnAction(event -> {
            logoutButton.setVisible(!logoutButton.isVisible());
        });

        menuList.setOnMouseClicked(event -> {
            menuListAnchorPane.setVisible(!menuListAnchorPane.isVisible());
            menuListAnchorPane.setManaged(!menuListAnchorPane.isManaged());

            if (menuListAnchorPane.isVisible()) {
                BorderPane.setMargin(contentPaneVBox, new javafx.geometry.Insets(0, 0, 0, 0));
            } else {
                BorderPane.setMargin(contentPaneVBox, new javafx.geometry.Insets(0, 0, 0, menuList.getFitWidth()));
            }
        });

        //ordersTableView.getStyleClass().add("my-table-view");
    }

    private void updateDateTime() {
        LocalDateTime currentDateTime = LocalDateTime.now();

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String formattedDateTime = currentDateTime.format(formatter);

        dateAndTimeLabel.setText(formattedDateTime);
    }

    private void openNewScene(String window) throws IOException {
        logoutButton.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(window));
        loader.load();

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));

        stage.initStyle(StageStyle.UNDECORATED);

        stage.showAndWait();
    }

    public void updateMainContent(String fileName) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fileName));
            Parent newPage = loader.load();
            mainContentAnchorPane.getChildren().setAll(newPage);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
