package com.example.restaurantis;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

public class LoginPageController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button exitButton;

    @FXML
    private Hyperlink forgotPasswordHyperlink;

    @FXML
    private Button loginButton;

    @FXML
    private Label loginLabel;

    @FXML
    private Label passwordLabel;

    @FXML
    private PasswordField passwordTextField;

    @FXML
    private Hyperlink signUpHyperlink;

    @FXML
    private TextField usernameTextField;

    UserAuthentication userAuthentication = new UserAuthentication();

    @FXML
    void initialize() {
        usernameTextField.textProperty().addListener(((observable, oldValue, newValue) -> {
            loginLabel.setVisible(newValue.isEmpty());
        }));

        passwordTextField.textProperty().addListener(((observable, oldValue, newValue) -> {
            passwordLabel.setVisible(newValue.isEmpty());
        }));

        loginButton.setOnAction(event -> {
            String usernameText = usernameTextField.getText().trim();
            String passwordText = passwordTextField.getText().trim();

            if (!usernameText.isEmpty() && !passwordText.isEmpty()) {
                if (userAuthentication.authenticateUser(usernameText, passwordText)) {
                    try {
                        openNewScene("main-page.fxml");
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    showAlert(Alert.AlertType.ERROR, "Authentication Failed", "Неверное имя пользователя или пароль.");
                }
            } else {
                showAlert(Alert.AlertType.ERROR, "Authentication Failed", "Введите имя пользователя или пароль.");
            }
        });

        loginButton.setOnMouseEntered(event -> {
            loginButton.setStyle("-fx-background-color: #ded8d7; -fx-text-fill: black;");
        });

        loginButton.setOnMouseExited(event -> {
            loginButton.setStyle("-fx-background-color: #ffffff; -fx-text-fill: black;");
        });

        exitButton.setOnAction(event -> {
            Stage stage = (Stage) exitButton.getScene().getWindow();
            stage.close();
        });
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void openNewScene(String window) throws IOException {
        loginButton.getScene().getWindow().hide();

        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource(window));
        loader.load();

        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));

        stage.initStyle(StageStyle.UNDECORATED);

        stage.showAndWait();
    }
}

