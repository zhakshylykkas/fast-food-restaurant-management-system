package com.example.restaurantis;

import java.io.File;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.FileChooser;

public class InventoryPageController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button addNewProductBtn;

    @FXML
    private Button clearFieldsBtn;

    @FXML
    private TableColumn<ProductData, String> dateTblClmn;

    @FXML
    private Button deleteProductBtn;

    @FXML
    private TableColumn<ProductData, String> priceTblClmn;

    @FXML
    private TableColumn<ProductData, String> productIDTblClmn;

    @FXML
    private TextField productIDTextField;

    @FXML
    private ImageView productImageView;

    @FXML
    private Button productImgLoadBtn;

    @FXML
    private TableColumn<ProductData, String> productNameTblClmn;

    @FXML
    private TextField productNameTextField;

    @FXML
    private TextField productPriceTextField;

    @FXML
    private ComboBox<String> productStatusComboBox;

    @FXML
    private TextField productStockTextField;

    @FXML
    private ComboBox<String> productTypeComboBox;

    @FXML
    private Button productUpdateBtn;

    @FXML
    private TableView<ProductData> productsTableView;

    @FXML
    private TableColumn<ProductData, String> statusTblClmn;

    @FXML
    private TableColumn<ProductData, String> stockTblClmn;

    @FXML
    private TableColumn<ProductData, String> typeTblClmn;

    DBHandler dbHandler = new DBHandler();
    private String[] statusList = {"Доступно", "Недоступно"};

    @FXML
    void initialize() {
        populateProductTypeComboBoxFromProductTypeTable(productTypeComboBox, "product_type", "type_name");
        populateProductStatusComboBox();
        inventoryShowData();

        addNewProductBtn.setOnAction(event -> {
            inventoryAddBtn();
        });

        productUpdateBtn.setOnAction(event -> {
            updateSelectedProduct();
        });

        deleteProductBtn.setOnAction(event -> {
            deleteSelectedProduct();
        });

        clearFieldsBtn.setOnAction(event -> {
            inventoryClearBtn();
        });

        productImgLoadBtn.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("Choose Image File");
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", "*.png", "*.jpg", "*.jpeg"));

            File selectedFile = fileChooser.showOpenDialog(productImgLoadBtn.getScene().getWindow());
            if (selectedFile != null) {
                String imagePath = selectedFile.getPath();

                String contentRootPath = new File("").getAbsolutePath();
                String pathFromContentRoot = imagePath.replace(contentRootPath, "");
                pathFromContentRoot = pathFromContentRoot.replace(File.separator, "/");

                Image image = new Image("file:" + imagePath);
                productImageView.setImage(image);
            }
        });
    }

    public void populateProductTypeComboBoxFromProductTypeTable
            (ComboBox<String> comboBox, String tableName, String columnName) {
        try {
            String query = "SELECT " + columnName + " FROM " + tableName;
            ResultSet resultSet = dbHandler.executeQuery(query);

            while (resultSet.next()) {
                String value = resultSet.getString(columnName);
                comboBox.getItems().add(value);
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public void populateProductStatusComboBox() {
        List<String> statusL = new ArrayList<>();
        for (String status : statusList) {
            statusL.add(status);
        }

        ObservableList listData = FXCollections.observableArrayList(statusL);
        productStatusComboBox.setItems(listData);
    }

    private ObservableList<ProductData> inventoryListData;
    public void inventoryShowData() {
        inventoryListData = dbHandler.inventoryProductsTable();

        productIDTblClmn.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameTblClmn.setCellValueFactory(new PropertyValueFactory<>("name"));
        typeTblClmn.setCellValueFactory(new PropertyValueFactory<>("type"));
        stockTblClmn.setCellValueFactory(new PropertyValueFactory<>("stock"));
        priceTblClmn.setCellValueFactory(new PropertyValueFactory<>("price"));
        statusTblClmn.setCellValueFactory(new PropertyValueFactory<>("status"));
        dateTblClmn.setCellValueFactory(new PropertyValueFactory<>("date"));

        productsTableView.setItems(inventoryListData);
    }

    public void inventoryAddBtn() {
        int newProductID = Integer.parseInt(productIDTextField.getText());
        String newProductName = productNameTextField.getText();
        String type = (String) productTypeComboBox.getSelectionModel().getSelectedItem();
        String stock = productStockTextField.getText();
        String price = productPriceTextField.getText();
        String status = (String) productStatusComboBox.getSelectionModel().getSelectedItem();

        Image image = productImageView.getImage();
        String imagePath = null;
        if (image != null) {
            String fullUrl = image.getUrl();
            String contentRoot = "file:" + System.getProperty("user.dir") + "/";
//            if (fullUrl.startsWith(contentRoot)) {
//                imagePath = fullUrl.substring(contentRoot.length());
//            }
            imagePath = fullUrl.substring(contentRoot.length());
        } else {
            showAlert(Alert.AlertType.ERROR, "Error Message", "Изображение не установлено.");
        }

        if (productIDTextField.getText().isEmpty()
                || productNameTextField.getText().isEmpty()
                || productTypeComboBox.getSelectionModel().getSelectedItem() == null
                || productStockTextField.getText().isEmpty()
                || productPriceTextField.getText().isEmpty()
                || productStatusComboBox.getSelectionModel().getSelectedItem() == null
                || imagePath == null) {

            showAlert(Alert.AlertType.ERROR,"Error Message", "Пожалуйста заполните все поля");
        } else {
            dbHandler.addNewProduct(newProductID, newProductName, type, stock, price, status, imagePath);
            inventoryShowData();
        }
    }

    private void showAlert(Alert.AlertType alertType, String title, String message) {
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public void inventorySelectData() {
        ProductData productData = productsTableView.getSelectionModel().getSelectedItem();
        int num = productsTableView.getSelectionModel().getSelectedIndex();

        if ((num - 1) < -1) return;

        productIDTextField.setText(String.valueOf(productData.getId()));
        productNameTextField.setText(productData.getName());
        productStockTextField.setText(String.valueOf(productData.getStock()));
        productPriceTextField.setText(String.valueOf(productData.getPrice()));
    }

    public void updateSelectedProduct() {
        int productID = Integer.parseInt(productIDTextField.getText());
        String productName = productNameTextField.getText();
        String type = (String) productTypeComboBox.getSelectionModel().getSelectedItem();
        String stock = productStockTextField.getText();
        String price = productPriceTextField.getText();
        String status = (String) productStatusComboBox.getSelectionModel().getSelectedItem();

        if (productIDTextField.getText().isEmpty()
                || productNameTextField.getText().isEmpty()
                || productTypeComboBox.getSelectionModel().getSelectedItem() == null
                || productStockTextField.getText().isEmpty()
                || productPriceTextField.getText().isEmpty()
                || productStatusComboBox.getSelectionModel().getSelectedItem() == null) {

            showAlert(Alert.AlertType.ERROR,"Error Message", "Пожалуйста заполните все поля");
        } else {
            dbHandler.updateProduct(productID, productName, type, stock, price, status);
            inventoryShowData();
            inventoryClearBtn();
        }
    }

    public void inventoryClearBtn() {
        productIDTextField.setText("");
        productNameTextField.setText("");
        productTypeComboBox.getSelectionModel().clearSelection();
        productStockTextField.setText("");
        productPriceTextField.setText("");
        productStatusComboBox.getSelectionModel().clearSelection();
    }

    public void deleteSelectedProduct() {
        int productID = Integer.parseInt(productIDTextField.getText());
        String productName = productNameTextField.getText();
        String type = (String) productTypeComboBox.getSelectionModel().getSelectedItem();
        String stock = productStockTextField.getText();
        String price = productPriceTextField.getText();
        String status = (String) productStatusComboBox.getSelectionModel().getSelectedItem();

        if (productIDTextField.getText().isEmpty()
                || productNameTextField.getText().isEmpty()
                //|| productTypeComboBox.getSelectionModel().getSelectedItem() == null
                || productStockTextField.getText().isEmpty()
                || productPriceTextField.getText().isEmpty()
                //|| productStatusComboBox.getSelectionModel().getSelectedItem() == null
        ) {
            showAlert(Alert.AlertType.ERROR,"Error Message", "Пожалуйста заполните все поля");
        } else {
            dbHandler.deleteProduct(productID, productName, type, stock, price, status);
            inventoryShowData();
            inventoryClearBtn();
        }
    }
}

