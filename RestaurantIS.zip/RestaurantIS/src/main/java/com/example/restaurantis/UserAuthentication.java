package com.example.restaurantis;

import java.sql.*;

public class UserAuthentication {
    public boolean authenticateUser(String username, String password) {
        try {
            DBHandler dbHandler = new DBHandler();
            Connection connection = dbHandler.getDbConnection();

            String query = "SELECT * FROM users WHERE username = ? AND password = ?";

            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return true;
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return false;
    }
}
