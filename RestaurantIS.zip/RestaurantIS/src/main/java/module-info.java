module com.example.restaurantis {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.restaurantis to javafx.fxml;
    exports com.example.restaurantis;
    exports com.example.restaurantis.DBTableClasses;
    opens com.example.restaurantis.DBTableClasses to javafx.fxml;
}